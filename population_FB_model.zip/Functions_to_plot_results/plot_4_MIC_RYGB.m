
%% Plot
 plot_hypotheses(0, 10);