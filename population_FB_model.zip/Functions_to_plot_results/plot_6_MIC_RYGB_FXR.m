

%% Plot
% close all
h   =   figure('units', 'normalized', 'Position', [0 0 .8 .8]);
h   =   plot_hypotheses(0, 10, h, 0);
plot_hypotheses(1, 10, h, 1)