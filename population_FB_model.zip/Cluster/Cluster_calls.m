
 CONTROL CALLS 
 
 % Must add quotes :
 % nohup matlab -nojvm -r 'setDirs; generate_control_plot(0, 1, 10)' -logfile outLOG_CONTROL_0_1_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(0, 1, 10) -logfile outLOG_CONTROL_0_1_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(1, 1, 10) -logfile outLOG_CONTROL_1_1_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(0, 2, 10) -logfile outLOG_CONTROL_0_2_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(1, 2, 10) -logfile outLOG_CONTROL_1_2_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(0, 3, 10) -logfile outLOG_CONTROL_0_3_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(1, 3, 10) -logfile outLOG_CONTROL_1_3_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(0, 4, 10) -logfile outLOG_CONTROL_0_4_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(1, 4, 10) -logfile outLOG_CONTROL_1_4_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(0, 5, 10) -logfile outLOG_CONTROL_0_5_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(1, 5, 10) -logfile outLOG_CONTROL_1_5_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(0, 6, 10) -logfile outLOG_CONTROL_0_6_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(1, 6, 10) -logfile outLOG_CONTROL_1_6_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(0, 7, 10) -logfile outLOG_CONTROL_0_7_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(1, 7, 10) -logfile outLOG_CONTROL_1_7_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(0, 8, 10) -logfile outLOG_CONTROL_0_8_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(1, 8, 10) -logfile outLOG_CONTROL_1_8_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(0, 11, 10) -logfile outLOG_CONTROL_0_11_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(1, 11, 10) -logfile outLOG_CONTROL_1_11_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(0, 12, 10) -logfile outLOG_CONTROL_0_12_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(1, 12, 10) -logfile outLOG_CONTROL_1_12_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(0, 13, 10) -logfile outLOG_CONTROL_0_13_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(1, 13, 10) -logfile outLOG_CONTROL_1_13_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(0, 14, 10) -logfile outLOG_CONTROL_0_14_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(1, 14, 10) -logfile outLOG_CONTROL_1_14_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(0, 15, 10) -logfile outLOG_CONTROL_0_15_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(1, 15, 10) -logfile outLOG_CONTROL_1_15_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(0, 16, 10) -logfile outLOG_CONTROL_0_16_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(1, 16, 10) -logfile outLOG_CONTROL_1_16_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(0, 17, 10) -logfile outLOG_CONTROL_0_17_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(1, 17, 10) -logfile outLOG_CONTROL_1_17_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(0, 18, 10) -logfile outLOG_CONTROL_0_18_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(1, 18, 10) -logfile outLOG_CONTROL_1_18_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(0, 19, 10) -logfile outLOG_CONTROL_0_19_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(1, 19, 10) -logfile outLOG_CONTROL_1_19_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(0, 20, 10) -logfile outLOG_CONTROL_0_20_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(1, 20, 10) -logfile outLOG_CONTROL_1_20_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(0, 21, 10) -logfile outLOG_CONTROL_0_21_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(1, 21, 10) -logfile outLOG_CONTROL_1_21_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(0, 22, 10) -logfile outLOG_CONTROL_0_22_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(1, 22, 10) -logfile outLOG_CONTROL_1_22_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(0, 23, 10) -logfile outLOG_CONTROL_0_23_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(1, 23, 10) -logfile outLOG_CONTROL_1_23_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(0, 24, 10) -logfile outLOG_CONTROL_0_24_10.OUT </dev/null & 
nohup matlab -nojvm -r setDirs; generate_control_plot(1, 24, 10) -logfile outLOG_CONTROL_1_24_10.OUT </dev/null & 
